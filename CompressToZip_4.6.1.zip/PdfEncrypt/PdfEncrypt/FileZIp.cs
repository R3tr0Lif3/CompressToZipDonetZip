﻿using System.IO;
namespace PdfEncrypt
{
    public class FileZIp
    {

        public void CoprimirArchivo()
        {
        }

    }
}
