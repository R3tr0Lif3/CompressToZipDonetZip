﻿using Ionic.Zip;

namespace CompressZip
{
    class Program
    {
        static void Main(string[] args)
        {
            string Folder = @"C:\Users\dguerrero\Desktop\Temp";
            string OutputFile = @"C:\Users\dguerrero\Desktop\Temp\Files\";
            string File = @"C:\Users\dguerrero\Desktop\Temp\1571272955945.pdf";

                using (ZipFile zip = new ZipFile())
                {             
                   //zip.AddFile(InputFile);
                   zip.Password = "1234";
                   //zip.AddDirectory(Folder);
                   zip.AddFile(File,"");
                   zip.Save(OutputFile+"fFile.zip");
                }
            
        }
    }
}
